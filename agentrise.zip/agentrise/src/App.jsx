import { useState } from "react";

const AGENTS = [
  {
    id: "website",
    name: "Website Agent",
    icon: "",
    desc: "Designs & plans your full website",
    prompt: (req) =>
      `You are a professional website design consultant at a top agency. A client says: "${req}". Give a clear, actionable website plan: recommended pages, hero section idea, color palette suggestion, and 3 key features to include. Be specific and inspiring. Keep it under 250 words.`,
  },
  {
    id: "app",
    name: "App Builder Agent",
    icon: "",
    desc: "Plans your mobile or web app",
    prompt: (req) =>
      `You are a senior product manager and app strategist. A client says: "${req}". Create a concise app blueprint: core features (pick the best 4), user flow summary, tech stack recommendation, and one key differentiator. Be practical and direct. Under 250 words.`,
  },
  {
    id: "copy",
    name: "Copywriting Agent",
    icon: "",
    desc: "Writes compelling business copy",
    prompt: (req) =>
      `You are an elite copywriter. A client says: "${req}". Write: a punchy headline, a 2-sentence tagline, a short about-us paragraph, and a call-to-action. Make it feel premium and human. Under 200 words.`,
  },
  {
    id: "strategy",
    name: "Business Strategy Agent",
    icon: "",
    desc: "Grows your business with a plan",
    prompt: (req) =>
      `You are a business growth strategist. A client says: "${req}". Provide: a 90-day action plan (3 phases), top 2 revenue opportunities, one bold move most businesses overlook, and a key metric to track. Be direct and specific. Under 250 words.`,
  },
  {
    id: "marketing",
    name: "Marketing Agent",
    icon: "",
    desc: "Creates your marketing strategy",
    prompt: (req) =>
      `You are a digital marketing expert. A client says: "${req}". Give: the best 3 channels to focus on, content ideas for each, a simple campaign concept, and one growth hack. Be actionable and concise. Under 250 words.`,
  },
];

const SERVICES = [
  { icon: "", title: "Website Design", desc: "Fast, beautiful websites built with AI precision" },
  { icon: "", title: "App Development", desc: "Web & mobile apps tailored to your business" },
  { icon: "", title: "Content & Copy", desc: "Words that convert browsers into buyers" },
  { icon: "", title: "Growth Strategy", desc: "Data-backed plans to scale your business" },
  { icon: "", title: "Digital Marketing", desc: "Reach the right people at the right time" },
];

function Spinner() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, color: "#a78bfa" }}><div style={{
        width: 18, height: 18, border: "3px solid #3b1d6e", borderTop: "3px solid #a78bfa",
        borderRadius: "50%", animation: "spin 0.8s linear infinite"
      }} />
      Agent thinking…
    </div>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", service: "", idea: "", contact: "" });
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit() {
    if (!form.name || !form.service || !form.idea || !form.contact) return;
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 16, padding: "48px 32px", textAlign: "center" }}><div style={{ fontSize: 48, marginBottom: 16 }}></div><h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 800, marginBottom: 12 }}>Request Received!</h3><p style={{ color: "#9ca3af", lineHeight: 1.7, marginBottom: 20 }}>
          Thanks <strong style={{ color: "#ffffff" }}>{form.name}</strong>! We have received your request for <strong style={{ color: "#ffffff" }}>{form.service}</strong>. We will review it and reach out to you at <strong style={{ color: "#ffffff" }}>{form.contact}</strong> shortly.
        </p><p style={{ color: "#6b7280", fontSize: 14 }}>Once we agree on price, send payment in USDT (TRC20) to get started.</p><button onClick={() => { setSubmitted(false); setForm({ name: "", service: "", idea: "", contact: "" }); }}
          style={{ marginTop: 20, background: "#1e1030", color: "#ffffff", border: "1px solid #4c1d95", borderRadius: 8, padding: "10px 24px", cursor: "pointer", fontWeight: 600 }}>
          Submit Another Request
        </button></div>
    );
  }

  const inputStyle = {
    width: "100%", background: "#0f0820", border: "1px solid #2d1b69",
    borderRadius: 10, padding: "13px 16px", color: "#ffffff",
    fontSize: 15, fontFamily: "inherit", outline: "none", marginBottom: 16
  };

  return (
    <div style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 16, padding: "36px 32px" }}><div style={{ marginBottom: 4, fontSize: 13, color: "#a78bfa", fontWeight: 600 }}>Your Name</div><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
        placeholder="e.g. John Doe" style={inputStyle} /><div style={{ marginBottom: 4, fontSize: 13, color: "#a78bfa", fontWeight: 600 }}>What Service Do You Need?</div><select value={form.service} onChange={e => setForm({ ...form, service: e.target.value })}
        style={{ ...inputStyle, appearance: "none" }}><option value="">Select a service...</option><option value="Website Design ($50–$500)">Website Design ($50–$500)</option><option value="AI Agent Rental ($17/hr)">AI Agent Rental ($17/hr)</option><option value="App Development (Custom Quote)">App Development (Custom Quote)</option></select><div style={{ marginBottom: 4, fontSize: 13, color: "#a78bfa", fontWeight: 600 }}>Describe Your Idea</div><textarea value={form.idea} onChange={e => setForm({ ...form, idea: e.target.value })}
        placeholder="Tell us about your project — what you need, your business, your goals..."
        rows={4} style={{ ...inputStyle, resize: "vertical" }} /><div style={{ marginBottom: 4, fontSize: 13, color: "#a78bfa", fontWeight: 600 }}>Your WhatsApp / Email</div><input value={form.contact} onChange={e => setForm({ ...form, contact: e.target.value })}
        placeholder="e.g. +234 800 000 0000 or you@email.com" style={inputStyle} /><button onClick={handleSubmit}
        disabled={!form.name || !form.service || !form.idea || !form.contact}
        style={{
          width: "100%", background: !form.name || !form.service || !form.idea || !form.contact ? "#2d1b69" : "#7c3aed",
          color: "#fff", border: "none", borderRadius: 10, padding: "15px",
          fontWeight: 700, cursor: !form.name || !form.service || !form.idea || !form.contact ? "not-allowed" : "pointer",
          fontSize: 16, transition: "background 0.2s"
        }}>
        Send Request →
      </button></div>
  );
}

function LandingPage({ onEnter }) {
  return (
    <div style={{ minHeight: "100vh", background: "#0a0613", color: "#ffffff", fontFamily: "'Inter', sans-serif" }}><style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Syne:wght@700;800&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulse { 0%,100% { opacity:.6; } 50% { opacity:1; } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #0a0613; }
        .glow { text-shadow: 0 0 60px rgba(167,139,250,0.4); }
        .card:hover { border-color: #7c3aed !important; transform: translateY(-2px); transition: all 0.2s; }
        .cta-btn:hover { background: #7c3aed !important; transform: scale(1.03); }
      `}</style>

      {/* Nav */}
      <nav style={{ padding: "20px 40px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #1e1030" }}><span style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, color: "#ffffff" }}>
           AgentRise
        </span><button onClick={onEnter} className="cta-btn" style={{
          background: "#6d28d9", color: "#fff", border: "none", borderRadius: 8,
          padding: "10px 22px", fontWeight: 600, cursor: "pointer", fontSize: 14, transition: "all 0.2s"
        }}>
          Launch Dashboard →
        </button></nav>

      {/* Hero */}
      <div style={{ textAlign: "center", padding: "100px 20px 60px", animation: "fadeUp 0.7s ease both" }}><div style={{ display: "inline-block", background: "#1a0d30", border: "1px solid #4c1d95", borderRadius: 20, padding: "6px 18px", fontSize: 13, color: "#a78bfa", marginBottom: 28 }}>
           AgentRise — AI-Powered Digital Agency
        </div><h1 className="glow" style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(42px, 7vw, 82px)", fontWeight: 800, lineHeight: 1.1, marginBottom: 24 }}>
          Agency-Grade Work.<br /><span style={{ color: "#a78bfa" }}>Fraction of the Cost.</span></h1><p style={{ fontSize: 18, color: "#9ca3af", maxWidth: 520, margin: "0 auto 40px", lineHeight: 1.7 }}>
          We build websites, apps, and growth systems powered by AI agents — so you get top-tier results without the top-tier price tag.
        </p><div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}><button onClick={onEnter} className="cta-btn" style={{
            background: "#7c3aed", color: "#fff", border: "none", borderRadius: 10,
            padding: "16px 36px", fontWeight: 700, cursor: "pointer", fontSize: 16, transition: "all 0.2s"
          }}>
            Try Our AI Agents Free →
          </button><button style={{
            background: "transparent", color: "#ffffff", border: "1px solid #4c1d95", borderRadius: 10,
            padding: "16px 28px", fontWeight: 600, cursor: "pointer", fontSize: 16
          }}>
            See Our Work
          </button></div></div>

      {/* Stats */}
      <div style={{ display: "flex", justifyContent: "center", gap: 60, padding: "20px 40px 60px", flexWrap: "wrap" }}>
        {[["10x", "Faster delivery"], ["80%", "Cost savings"], ["100+", "Businesses served"]].map(([n, l]) => (
          <div key={n} style={{ textAlign: "center" }}><div style={{ fontFamily: "'Syne', sans-serif", fontSize: 42, fontWeight: 800, color: "#a78bfa" }}>{n}</div><div style={{ color: "#6b7280", fontSize: 14 }}>{l}</div></div>
        ))}
      </div>

      {/* Services */}
      <div style={{ padding: "20px 40px 80px", maxWidth: 1100, margin: "0 auto" }}><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 32, fontWeight: 800, textAlign: "center", marginBottom: 40 }}>
          What We Build For You
        </h2><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 20 }}>
          {SERVICES.map((s) => (
            <div key={s.title} className="card" style={{
              background: "#0f0820", border: "1px solid #1e1030", borderRadius: 14,
              padding: "28px 22px", cursor: "default"
            }}><div style={{ fontSize: 32, marginBottom: 12 }}>{s.icon}</div><div style={{ fontWeight: 700, fontSize: 16, marginBottom: 8 }}>{s.title}</div><div style={{ color: "#6b7280", fontSize: 14, lineHeight: 1.6 }}>{s.desc}</div></div>
          ))}
        </div></div>

      {/* Pricing Section */}
      <div style={{ padding: "80px 40px", maxWidth: 1100, margin: "0 auto" }}><div style={{ textAlign: "center", marginBottom: 50 }}><div style={{ display: "inline-block", background: "#1a0d30", border: "1px solid #4c1d95", borderRadius: 20, padding: "6px 18px", fontSize: 13, color: "#a78bfa", marginBottom: 20 }}>
             Simple, Transparent Pricing
          </div><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 36, fontWeight: 800, marginBottom: 12 }}>What You Pay</h2><p style={{ color: "#9ca3af", fontSize: 16 }}>No hidden fees. No surprises. Just results.</p></div><div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 24 }}><div className="card" style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 16, padding: "32px 28px" }}><div style={{ fontSize: 36, marginBottom: 12 }}></div><div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>Website Design</div><div style={{ fontSize: 32, fontWeight: 800, color: "#a78bfa", marginBottom: 4 }}>$50 – $500</div><div style={{ color: "#6b7280", fontSize: 13, marginBottom: 20 }}>Based on size and complexity</div><ul style={{ listStyle: "none", padding: 0, marginBottom: 28 }}>
              {["Landing page or full site", "Mobile-friendly design", "Fast delivery", "Built to convert visitors"].map(f => (
                <li key={f} style={{ color: "#e8e8e8", fontSize: 14, padding: "6px 0", borderBottom: "1px solid #1e1030" }}> {f}</li>
              ))}
            </ul><button onClick={onEnter} style={{ width: "100%", background: "#7c3aed", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontWeight: 700, cursor: "pointer", fontSize: 15 }}>Get Started →</button></div><div className="card" style={{ background: "#140b28", border: "2px solid #7c3aed", borderRadius: 16, padding: "32px 28px", position: "relative" }}><div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "#7c3aed", color: "#fff", borderRadius: 20, padding: "4px 16px", fontSize: 12, fontWeight: 700, whiteSpace: "nowrap" }}> MOST POPULAR</div><div style={{ fontSize: 36, marginBottom: 12 }}></div><div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>AI Agent Rental</div><div style={{ fontSize: 32, fontWeight: 800, color: "#a78bfa", marginBottom: 4 }}>$17<span style={{ fontSize: 16, color: "#6b7280" }}>/hour</span></div><div style={{ color: "#6b7280", fontSize: 13, marginBottom: 20 }}>Pay only for what you use</div><ul style={{ listStyle: "none", padding: 0, marginBottom: 28 }}>
              {["Access to all 5 AI agents", "Strategy, copy and marketing", "Business growth planning", "Instant AI-powered results"].map(f => (
                <li key={f} style={{ color: "#e8e8e8", fontSize: 14, padding: "6px 0", borderBottom: "1px solid #1e1030" }}> {f}</li>
              ))}
            </ul><button onClick={onEnter} style={{ width: "100%", background: "#7c3aed", color: "#fff", border: "none", borderRadius: 10, padding: "13px", fontWeight: 700, cursor: "pointer", fontSize: 15 }}>Try Agents Now →</button></div><div className="card" style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 16, padding: "32px 28px" }}><div style={{ fontSize: 36, marginBottom: 12 }}></div><div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>App Development</div><div style={{ fontSize: 32, fontWeight: 800, color: "#a78bfa", marginBottom: 4 }}>Custom Quote</div><div style={{ color: "#6b7280", fontSize: 13, marginBottom: 20 }}>Priced after reviewing your idea</div><ul style={{ listStyle: "none", padding: 0, marginBottom: 28 }}>
              {["Web and mobile apps", "Tell us your idea", "We review and send you a price", "Built to your exact needs"].map(f => (
                <li key={f} style={{ color: "#e8e8e8", fontSize: 14, padding: "6px 0", borderBottom: "1px solid #1e1030" }}> {f}</li>
              ))}
            </ul><button onClick={onEnter} style={{ width: "100%", background: "#1e1030", color: "#ffffff", border: "1px solid #4c1d95", borderRadius: 10, padding: "13px", fontWeight: 700, cursor: "pointer", fontSize: 15 }}>Request a Quote →</button></div></div></div>

      {/* CTA Banner */}
      <div style={{ background: "#140b28", borderTop: "1px solid #1e1030", borderBottom: "1px solid #1e1030", padding: "60px 40px", textAlign: "center" }}><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 36, fontWeight: 800, marginBottom: 16 }}>
          Ready to grow your business?
        </h2><p style={{ color: "#9ca3af", marginBottom: 28 }}>Talk to one of our AI agents right now — no signup needed.</p><button onClick={onEnter} className="cta-btn" style={{
          background: "#7c3aed", color: "#fff", border: "none", borderRadius: 10,
          padding: "16px 36px", fontWeight: 700, cursor: "pointer", fontSize: 16, transition: "all 0.2s"
        }}>
          Open Agent Dashboard →
        </button></div>

      {/* Contact Form */}
      <div style={{ padding: "80px 40px", maxWidth: 680, margin: "0 auto" }}><div style={{ textAlign: "center", marginBottom: 44 }}><div style={{ display: "inline-block", background: "#1a0d30", border: "1px solid #4c1d95", borderRadius: 20, padding: "6px 18px", fontSize: 13, color: "#a78bfa", marginBottom: 20 }}>
             Get In Touch
          </div><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 36, fontWeight: 800, marginBottom: 12 }}>Start Your Project</h2><p style={{ color: "#9ca3af", fontSize: 16 }}>Tell us what you need and we will get back to you fast.</p></div><ContactForm /></div>

      {/* Payment Section */}
      <div style={{ padding: "70px 40px", maxWidth: 600, margin: "0 auto", textAlign: "center" }}><div style={{ display: "inline-block", background: "#1a0d30", border: "1px solid #4c1d95", borderRadius: 20, padding: "6px 18px", fontSize: 13, color: "#a78bfa", marginBottom: 24 }}>
           Crypto Payments Accepted
        </div><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 30, fontWeight: 800, marginBottom: 12 }}>Pay With USDT (TRC20)</h2><p style={{ color: "#9ca3af", marginBottom: 32, lineHeight: 1.7 }}>
          We accept USDT on the TRON network (TRC20). Fast, low-fee, and secure. Send your payment to the address below and share the transaction ID with us to get started.
        </p><div style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 14, padding: "28px 24px", marginBottom: 20 }}><div style={{ fontSize: 12, color: "#6b7280", marginBottom: 10, letterSpacing: 1, textTransform: "uppercase", fontWeight: 600 }}>USDT TRC20 Wallet Address</div><div style={{ fontFamily: "monospace", fontSize: 15, color: "#ffffff", wordBreak: "break-all", marginBottom: 16 }}>
            TCirQYMB5RMVC39MurSmhLSa2rWvWaQnJE
          </div><button
            onClick={() => navigator.clipboard.writeText("TCirQYMB5RMVC39MurSmhLSa2rWvWaQnJE")}
            style={{
              background: "#7c3aed", color: "#fff", border: "none", borderRadius: 8,
              padding: "10px 24px", fontWeight: 600, cursor: "pointer", fontSize: 14
            }}>
            Copy Address
          </button></div><div style={{ background: "#0f0820", border: "1px solid #1e1030", borderRadius: 12, padding: "16px 20px", textAlign: "left" }}><div style={{ fontSize: 13, color: "#6b7280", lineHeight: 1.8 }}><strong style={{ color: "#a78bfa" }}>Important:</strong> Only send <strong>USDT on the TRC20 network</strong>. Sending other tokens or using a different network may result in permanent loss of funds.
          </div></div></div><div style={{ padding: "24px", textAlign: "center", color: "#374151", fontSize: 13, borderTop: "1px solid #1e1030" }}>
        © 2026 AgentRise · AI-powered. Human-curated.
      </div></div>
  );
}

function Dashboard({ onBack }) {
  const [activeAgent, setActiveAgent] = useState(null);
  const [request, setRequest] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  async function runAgent() {
    if (!request.trim() || !activeAgent) return;
    setLoading(true);
    setResponse("");
    const agent = AGENTS.find((a) => a.id === activeAgent);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          messages: [{ role: "user", content: agent.prompt(request) }],
        }),
      });
      const data = await res.json();
      const text = data.content?.map((c) => c.text || "").join("") || "No response.";
      setResponse(text);
      setHistory((h) => [{ agent: agent.name, icon: agent.icon, req: request, res: text }, ...h.slice(0, 4)]);
    } catch {
      setResponse("Something went wrong. Please try again.");
    }
    setLoading(false);
  }

  return (
    <div style={{ minHeight: "100vh", background: "#0a0613", color: "#ffffff", fontFamily: "'Inter', sans-serif" }}><style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Syne:wght@700;800&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        textarea:focus { outline: none; border-color: #7c3aed !important; }
        .agent-card:hover { border-color: #7c3aed !important; background: #140b28 !important; }
      `}</style>

      {/* Header */}
      <div style={{ padding: "18px 32px", borderBottom: "1px solid #1e1030", display: "flex", alignItems: "center", gap: 20 }}><button onClick={onBack} style={{ background: "none", border: "1px solid #2d1b69", color: "#a78bfa", borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontSize: 13 }}>
          ← Back
        </button><span style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20, color: "#ffffff" }}> AgentRise — Agent Dashboard</span></div><div style={{ display: "grid", gridTemplateColumns: "260px 1fr", minHeight: "calc(100vh - 65px)" }}>
        {/* Sidebar */}
        <div style={{ borderRight: "1px solid #1e1030", padding: "28px 20px" }}><div style={{ fontSize: 11, fontWeight: 600, color: "#6d28d9", letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 16 }}>
            Select Agent
          </div>
          {AGENTS.map((a) => (
            <div key={a.id} className="agent-card" onClick={() => { setActiveAgent(a.id); setResponse(""); setRequest(""); }}
              style={{
                padding: "14px 16px", borderRadius: 10, marginBottom: 8, cursor: "pointer",
                border: `1px solid ${activeAgent === a.id ? "#7c3aed" : "#1e1030"}`,
                background: activeAgent === a.id ? "#140b28" : "transparent",
                transition: "all 0.15s"
              }}><div style={{ display: "flex", alignItems: "center", gap: 10 }}><span style={{ fontSize: 22 }}>{a.icon}</span><div><div style={{ fontWeight: 600, fontSize: 14 }}>{a.name}</div><div style={{ color: "#6b7280", fontSize: 12 }}>{a.desc}</div></div></div></div>
          ))}

          {history.length > 0 && (
            <><div style={{ fontSize: 11, fontWeight: 600, color: "#6d28d9", letterSpacing: 1.5, textTransform: "uppercase", margin: "28px 0 12px" }}>
                Recent
              </div>
              {history.map((h, i) => (
                <div key={i} onClick={() => { setActiveAgent(AGENTS.find(a=>a.name===h.agent)?.id); setRequest(h.req); setResponse(h.res); }}
                  style={{ padding: "10px 12px", borderRadius: 8, marginBottom: 6, background: "#0f0820", cursor: "pointer", border: "1px solid #1e1030" }}><div style={{ fontSize: 12, color: "#a78bfa", marginBottom: 2 }}>{h.icon} {h.agent}</div><div style={{ fontSize: 12, color: "#6b7280", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{h.req}</div></div>
              ))}
            </>
          )}
        </div>

        {/* Main */}
        <div style={{ padding: "36px 40px" }}>
          {!activeAgent ? (
            <div style={{ textAlign: "center", paddingTop: 80 }}><div style={{ fontSize: 48, marginBottom: 16 }}></div><h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: 28, fontWeight: 800, marginBottom: 12 }}>Pick an Agent to Get Started</h2><p style={{ color: "#6b7280" }}>Choose an AI agent from the left panel and describe what your client needs.</p></div>
          ) : (
            <div style={{ animation: "fadeUp 0.4s ease both", maxWidth: 760 }}>
              {(() => {
                const agent = AGENTS.find((a) => a.id === activeAgent);
                return (
                  <><div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 28 }}><span style={{ fontSize: 36 }}>{agent.icon}</span><div><h2 style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 24 }}>{agent.name}</h2><p style={{ color: "#6b7280", fontSize: 14 }}>{agent.desc}</p></div></div><div style={{ marginBottom: 16 }}><label style={{ fontSize: 13, fontWeight: 600, color: "#a78bfa", display: "block", marginBottom: 8 }}>
                        Describe what the client needs
                      </label><textarea
                        value={request}
                        onChange={(e) => setRequest(e.target.value)}
                        placeholder={`e.g. "I run a bakery in Lagos and need a website to take orders online"`}
                        rows={4}
                        style={{
                          width: "100%", background: "#0f0820", border: "1px solid #2d1b69",
                          borderRadius: 10, padding: "14px 16px", color: "#ffffff",
                          fontSize: 15, resize: "vertical", fontFamily: "inherit", lineHeight: 1.6, transition: "border 0.2s"
                        }}
                      /></div><button
                      onClick={runAgent}
                      disabled={loading || !request.trim()}
                      style={{
                        background: loading || !request.trim() ? "#2d1b69" : "#7c3aed",
                        color: "#fff", border: "none", borderRadius: 10,
                        padding: "14px 28px", fontWeight: 700, cursor: loading || !request.trim() ? "not-allowed" : "pointer",
                        fontSize: 15, marginBottom: 28, transition: "background 0.2s"
                      }}
                    >
                      {loading ? "Running Agent…" : `Run ${agent.name} →`}
                    </button>

                    {loading && <Spinner />}

                    {response && !loading && (
                      <div style={{ background: "#0f0820", border: "1px solid #2d1b69", borderRadius: 12, padding: "24px 26px", animation: "fadeUp 0.4s ease both" }}><div style={{ fontSize: 12, fontWeight: 600, color: "#a78bfa", marginBottom: 14, letterSpacing: 1 }}>
                          {agent.icon} AGENT RESPONSE
                        </div><div style={{ lineHeight: 1.8, fontSize: 15, color: "#f5f5f5", whiteSpace: "pre-wrap" }}>
                          {response}
                        </div><div style={{ marginTop: 20, display: "flex", gap: 10 }}><button
                            onClick={() => navigator.clipboard.writeText(response)}
                            style={{ background: "#1e1030", border: "1px solid #2d1b69", color: "#ffffff", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontSize: 13 }}>
                            Copy Response
                          </button><button
                            onClick={() => { setResponse(""); setRequest(""); }}
                            style={{ background: "transparent", border: "1px solid #2d1b69", color: "#6b7280", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontSize: 13 }}>
                            New Request
                          </button></div></div>
                    )}
                  </>
                );
              })()}
            </div>
          )}
        </div></div></div>
  );
}

export default function App() {
  const [view, setView] = useState("landing");
  return view === "landing"
    ? <LandingPage onEnter={() => setView("dashboard")} />
    : <Dashboard onBack={() => setView("landing")} />;
}
