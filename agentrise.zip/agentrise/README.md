# AgentRise — AI-Powered Digital Agency

## How to Deploy (Step by Step)

### Step 1 — Create GitHub Account
1. Go to github.com
2. Click "Sign Up" and create a free account

### Step 2 — Upload This Project
1. On GitHub, click the "+" button → "New repository"
2. Name it: agentrise
3. Click "Create repository"
4. Click "uploading an existing file"
5. Drag and drop ALL these files and folders into GitHub
6. Click "Commit changes"

### Step 3 — Deploy on Vercel
1. Go to vercel.com
2. Click "Sign Up" → choose "Continue with GitHub"
3. Click "Add New Project"
4. Select your "agentrise" repository
5. Click "Deploy"
6. Wait 1 minute — your site is LIVE!

### Step 4 — Your Live Link
Vercel gives you a free link like:
agentrise.vercel.app

Share this link everywhere to get clients!

---
Built with AgentRise © 2026
